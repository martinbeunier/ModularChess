@echo off
title Spousteni hraciho programu ModularChess
echo Spoustim hru...
java -jar "Chess.jar"
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [CHYBA] Nepodarilo se spustit aplikaci. Zkontrolovat Javu nebo chybove hlasky vyse.
    pause
)