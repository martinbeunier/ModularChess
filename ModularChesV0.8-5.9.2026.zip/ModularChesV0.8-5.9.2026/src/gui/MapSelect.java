package gui;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Random;

public class MapSelect extends JPanel {

    private MainFrame frame;

    private JTextField searchField;
    private JPanel mapsPanel;
    private ButtonGroup mapGroup;

    private ArrayList<String> maps;

    public MapSelect(MainFrame frame) {

        this.frame = frame;

        int w = frame.getWidth();
        int h = frame.getHeight();

        setLayout(null);
        setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        // --------------------------------------------------
        // MAPY
        // --------------------------------------------------

        maps = new ArrayList<>();

        maps.add("standard");
        maps.add("map1 fighter defense");
        maps.add("WaterFight");
        maps.add("test");

        mapGroup = new ButtonGroup();

        // --------------------------------------------------
        // START BUTTON
        // --------------------------------------------------

        JButton startB = new JButton("Start");

        startB.setBounds(
                UI.toCenter(20, w),
                UI.toPercent(60, h),
                UI.toPercent(20, w),
                UI.toPercent(10, h)
        );

        // --------------------------------------------------
        // SEARCH
        // --------------------------------------------------

        searchField = new JTextField();

        searchField.setBounds(
                UI.toPercent(20, w),
                UI.toPercent(10, h),
                UI.toPercent(40, w),
                UI.toPercent(5, h)
        );

        // --------------------------------------------------
        // MAP PANEL
        // --------------------------------------------------

        mapsPanel = new JPanel();

        mapsPanel.setLayout(
                new FlowLayout(FlowLayout.LEFT)
        );

        JScrollPane scrollPane = new JScrollPane(mapsPanel);

        scrollPane.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS
        );

        scrollPane.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_NEVER
        );

        scrollPane.setBounds(
                UI.toPercent(20, w),
                UI.toPercent(20, h),
                UI.toPercent(60, w),
                UI.toPercent(20, h)
        );

        // --------------------------------------------------
        // VÝBĚR BOTA
        // --------------------------------------------------

        JPanel radioPanel = new JPanel();

        radioPanel.setLayout(null);

        radioPanel.setBounds(
                UI.toPercent(15, w),
                UI.toPercent(60, h),
                UI.toPercent(30, w),
                UI.toPercent(15, h)
        );

        ButtonGroup group = new ButtonGroup();

        JRadioButton selfButton =
                new JRadioButton("Against yourself");

        selfButton.setBounds(
                0,
                0,
                UI.toPercent(15, w),
                UI.toPercent(3, h)
        );

        selfButton.setActionCommand("Against yourself");

        JRadioButton bot1Button =
                new JRadioButton("Bold man bot : Dificulty 1/10");

        bot1Button.setBounds(
                0,
                UI.toPercent(3, h),
                UI.toPercent(15, w),
                UI.toPercent(3, h)
        );
        bot1Button.setActionCommand("Bot 1");

        JRadioButton bot2Button =
                new JRadioButton("Greedy bot : Dificulty 2/10");

        bot2Button.setBounds(
                0,
                UI.toPercent(6, h),
                UI.toPercent(15, w),
                UI.toPercent(3, h)
        );

        bot2Button.setActionCommand("Bot 2");

        JRadioButton bot3Button =
                new JRadioButton("Trapper bot : Dificulty 6/10");

        bot3Button.setBounds(
                0,
                UI.toPercent(9, h),
                UI.toPercent(15, w),
                UI.toPercent(3, h)
        );

        bot3Button.setActionCommand("Bot 3");


        group.add(selfButton);
        group.add(bot1Button);
        group.add(bot2Button);
        group.add(bot3Button);

        radioPanel.add(selfButton);
        radioPanel.add(bot1Button);
        radioPanel.add(bot2Button);
        radioPanel.add(bot3Button);

        // --------------------------------------------------
        // Výběr barvy
        // --------------------------------------------------
        JPanel radioPanelColour = new JPanel();

        radioPanelColour.setLayout(null);

        ButtonGroup groupColour = new ButtonGroup();

        radioPanelColour.setBounds(
                UI.toPercent(40, w),
                UI.toPercent(50, h),
                UI.toPercent(30, w),
                UI.toPercent(15, h)
        );


        JRadioButton whiteButton =
                new JRadioButton("White");

        whiteButton.setBounds(
                0,
                0,
                UI.toPercent(5, w),
                UI.toPercent(3, h)
        );

        whiteButton.setActionCommand("White");
        groupColour.add(whiteButton);
        radioPanelColour.add(whiteButton);

        JRadioButton randomButton =
                new JRadioButton("Random");


        randomButton.setBounds(
                UI.toPercent(7, w),
                0,
                UI.toPercent(5, w),
                UI.toPercent(3, h)
        );

        randomButton.setActionCommand("Random");
        groupColour.add(randomButton);
        radioPanelColour.add(randomButton);

        JRadioButton blackButton =
                new JRadioButton("Black");

        blackButton.setBounds(
                UI.toPercent(14, w),
                0,
                UI.toPercent(5, w),
                UI.toPercent(3, h)
        );

        blackButton.setActionCommand("Black");
        groupColour.add(blackButton);
        radioPanelColour.add(blackButton);

        randomButton.setSelected(true);
        // --------------------------------------------------
        // PŘIDÁNÍ KOMPONENT
        // --------------------------------------------------

        add(startB);
        add(scrollPane);
        add(searchField);
        add(radioPanel);
        add(radioPanelColour);

        // --------------------------------------------------
        // PRVNÍ VYKRESLENÍ MAP
        // --------------------------------------------------

        updateMaps();

        // --------------------------------------------------
        // SEARCH LISTENER
        // --------------------------------------------------

        searchField.getDocument().addDocumentListener(
                new DocumentListener() {

                    @Override
                    public void insertUpdate(DocumentEvent e) {
                        updateMaps();
                    }

                    @Override
                    public void removeUpdate(DocumentEvent e) {
                        updateMaps();
                    }

                    @Override
                    public void changedUpdate(DocumentEvent e) {
                        updateMaps();
                    }
                }
        );

        // --------------------------------------------------
        // START
        // --------------------------------------------------

        startB.addActionListener(e -> {

            ButtonModel selectedMapModel =
                    mapGroup.getSelection();

            ButtonModel selectedBotModel =
                    group.getSelection();

            ButtonModel selectedColourModel = groupColour.getSelection();

            // ----------------------------------------------
            // KONTROLA MAPY
            // ----------------------------------------------

            if (selectedMapModel == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Vyber prosím mapu!"
                );

                return;
            }

            // ----------------------------------------------
            // KONTROLA PROTIVNÍKA
            // ----------------------------------------------

            if (selectedBotModel == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Vyber prosím protivníka!"
                );

                return;
            }

            // ----------------------------------------------
            // ZÍSKÁNÍ VÝBĚRU
            // ----------------------------------------------

            String map =
                    selectedMapModel.getActionCommand();

            String bot =
                    selectedBotModel.getActionCommand();
            String colour
                    = selectedColourModel.getActionCommand();

            System.out.println("Selected map: " + map);
            System.out.println("Selected opponent: " + bot);
            System.out.println("Selected colour: " + colour);

            // ----------------------------------------------
            // PŘEDÁNÍ DO LOOP
            // ----------------------------------------------

            Loop loop = frame.getLoopPanel();

            loop.setSelectedMap(map);
            loop.setSelectedOpponent(bot);

            if(colour.equals("Random")) {
                Random random = new Random();

                if(random.nextInt(2) == 0    ){colour = "Black";}else{colour = "White";}
            }

            loop.setSelectedColour(colour);

            loop.startGame();

            frame.showScene("LOOP");
        });

        // --------------------------------------------------
        // ESC
        // --------------------------------------------------

        getInputMap(
                WHEN_IN_FOCUSED_WINDOW
        ).put(
                KeyStroke.getKeyStroke("ESCAPE"),
                "backTo"
        );

        getActionMap().put(
                "backTo",
                new AbstractAction() {

                    @Override
                    public void actionPerformed(ActionEvent e) {

                        frame.showScene("PLAYMENU");
                    }
                }
        );
    }

    // ======================================================
    // VYKRESLENÍ / FILTROVÁNÍ MAP
    // ======================================================

    private void updateMaps() {

        /*
         * Zapamatujeme si právě vybranou mapu.
         *
         * To je důležité, protože při removeAll()
         * původní JToggleButton zmizí.
         */

        String selectedMap = null;

        ButtonModel selected =
                mapGroup.getSelection();

        if (selected != null) {
            selectedMap =
                    selected.getActionCommand();
        }

        // --------------------------------------------------
        // ODSTRANĚNÍ STARÝCH TLAČÍTEK Z BUTTON GROUP
        // --------------------------------------------------

        /*
         * ButtonGroup nemá clear().
         *
         * Proto projdeme všechny jeho tlačítka
         * a odstraníme je.
         */

        ArrayList<AbstractButton> oldButtons =
                new ArrayList<>();

        for (java.util.Enumeration<AbstractButton> e =
             mapGroup.getElements();
             e.hasMoreElements();) {

            oldButtons.add(e.nextElement());
        }

        for (AbstractButton button : oldButtons) {
            mapGroup.remove(button);
        }

        // --------------------------------------------------
        // ODSTRANĚNÍ STARÝCH KOMPONENT
        // --------------------------------------------------

        mapsPanel.removeAll();

        // --------------------------------------------------
        // FILTR
        // --------------------------------------------------

        String filter =
                searchField.getText()
                        .trim()
                        .toLowerCase();

        // --------------------------------------------------
        // VYTVOŘENÍ MAP
        // --------------------------------------------------

        for (String map : maps) {

            if (!map.toLowerCase().contains(filter)) {
                continue;
            }

            JToggleButton mapButton =
                    new JToggleButton(map);

            /*
             * ActionCommand musí obsahovat skutečný
             * název mapy.
             */

            mapButton.setActionCommand(map);

            /*
             * Přidáme tlačítko do ButtonGroup.
             */

            mapGroup.add(mapButton);

            /*
             * A zároveň do GUI.
             */

            mapsPanel.add(mapButton);

            // --------------------------------------------------
            // OBNOVENÍ PŮVODNÍHO VÝBĚRU
            // --------------------------------------------------

            if (map.equals(selectedMap)) {
                mapButton.setSelected(true);
            }
        }

        // --------------------------------------------------
        // REFRESH GUI
        // --------------------------------------------------

        mapsPanel.revalidate();
        mapsPanel.repaint();
    }
}